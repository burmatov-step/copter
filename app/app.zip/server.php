<?php
sleep(5);
echo $_SERVER['REMOTE_ADDR'];
